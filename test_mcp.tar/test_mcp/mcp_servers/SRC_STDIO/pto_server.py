from mcp.server.fastmcp import FastMCP

# Create an MCP server with increased timeout
mcp = FastMCP("timeoff_server")

# Define our tool
@mcp.tool()
def check_vacation_balance(employee_name: str) -> any:
    """Check the vacation balance for a given employee. Return 0 if not found."""
    vac_dict = {"John Doe": 10, "Jane Smith": 5, "Alice Johnson": 12, "Bob Brown": 3, "Charlie Black": 8, "John Smith": 7}
    try:
        # Add robust error handling
        if not isinstance(employee_name, str):
            return "No employee name provided"
        if employee_name in vac_dict:
            return vac_dict[employee_name]
        else:
            # check if the first name is in the dictionary
            first_name = employee_name.split()[0]
            for name in vac_dict.keys():
                if name.startswith(first_name):
                    return vac_dict[name]
        # If not found, return 0
        return "Could not find the employee in the dictionary"
    except KeyError:
        # Return 0 on any error
        return "Could not find the employee in the dictionary"
    except TypeError:
        # Return 0 on any error
        return "Could not find the employee in the dictionary"
    except ValueError:
        # Return 0 on any error
        return "Could not find the employee in the dictionary"

    except Exception as e:
        # Return 0 on any error
        return 0

@mcp.tool()
def timeoff_requeest(pto_type, start_date: str, end_date) -> any:
    """Time off requestion with PTO type, start date and end date for the time off.
    args:
       pto_type: the time off type (vacation, sick time or jury duty).
       start_date: the time off starting date. The date will be in mm-dd-yyyy format. For example 04-15-2025.
       end_date: the time off ending date. The date should also be in mm-dd-yyyy format. 
    return:
       a json string like {"pto_type": "sick time", "start_date": "04-15-2025", "end_date": "04-18-2025"}
    """
    return {"pto_type": pto_type, "start_date": start_date, "end_date": end_date}


if __name__ == "__main__":
    # Use this approach to keep the server running
    mcp.run()
