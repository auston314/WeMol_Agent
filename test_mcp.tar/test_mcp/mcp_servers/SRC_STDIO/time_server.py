from mcp.server.fastmcp import FastMCP
from datetime import datetime

mcp = FastMCP("time_date_server")

@mcp.tool()
def get_current_time():
    """Get the local date and time in ISO 8601 format."""
    return datetime.now().isoformat()

if __name__ == "__main__":
    mcp.run(transport='stdio')

